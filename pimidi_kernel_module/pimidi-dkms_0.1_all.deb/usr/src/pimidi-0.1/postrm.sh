#!/bin/sh

rm -f /lib/udev/rules.d/41-pimidi.rules
