#!/bin/sh

cp ./41-pimidi.rules /lib/udev/rules.d/
